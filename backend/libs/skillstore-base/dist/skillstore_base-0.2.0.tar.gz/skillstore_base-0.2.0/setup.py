# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['skillstore_base']

package_data = \
{'': ['*']}

install_requires = \
['boto3>=1.38.15']

setup_kwargs = {
    'name': 'skillstore_base',
    'version': '0.2.0',
    'description': 'Core utilities for SkillStore Lambda functions',
    'long_description': '# skillstore_base\n\nCore utilities for SkillStore Lambda functions. Extracted from skillflow_base.\n',
    'author': 'Craig Trim',
    'author_email': 'ctrim@maryville.edu',
    'maintainer': 'Craig Trim',
    'maintainer_email': 'ctrim@maryville.edu',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10',
}


setup(**setup_kwargs)
